﻿from __future__ import annotations

import json
import queue
import random
import re
import shutil
import subprocess
import threading
import time
import traceback
import urllib.error
import urllib.request
from collections import deque
from datetime import datetime
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Optional

from PyQt6.QtCore import QObject, pyqtSignal, pyqtSlot

from config.constants import DEFAULT_SOURCE_MODE
from config.models import AppConfig
from core.io_utils import (
    last_json_line as _last_json_line,
    save_text as _save_text,
    wav_duration_sec as _wav_duration_sec,
    with_utf8_env as _with_utf8_env,
)

PROJECT_ROOT = Path(__file__).resolve().parent.parent

class PipelineWorker(QObject):
    finished = pyqtSignal()
    error = pyqtSignal(str)
    log = pyqtSignal(str)

    def __init__(self, cfg: AppConfig) -> None:
        super().__init__()
        self._cfg = cfg
        self._running = True
        self._paused = False
        self._observer = None
        self._wav_queue: queue.Queue[Path] = queue.Queue(maxsize=1024)
        self._text_queue: queue.Queue[str] = queue.Queue(maxsize=256)
        self._seen: set[str] = set()
        self._lock = threading.Lock()
        self._transcribe_conv_lock = threading.Lock()
        self._transcribe_conv_rules: list[dict] = list(cfg.transcribe_conversion_dict or [])
        self._transcribe_proc: Optional[subprocess.Popen] = None
        self._sbv2_proc: Optional[subprocess.Popen] = None
        self._sbv2_log_tail: deque[str] = deque(maxlen=200)
        self._sbv2_log_lock = threading.Lock()
        self._sbv2_last_exit_code: Optional[int] = None
        self._sbv2_last_exit_at: str = ""
        self._current_proc: Optional[subprocess.Popen] = None
        self._proc_lock = threading.Lock()
        self._external_server: Optional[ThreadingHTTPServer] = None
        self._external_server_thread: Optional[threading.Thread] = None
        self._external_id_queue: deque[str] = deque()
        self._external_id_set: set[str] = set()
        self._external_lock = threading.Lock()
        # song_kana_map / video_metadata
        _data_dir = PROJECT_ROOT / "data"
        self._song_kana_map_path: Path = _data_dir / "song_kana_map.json"
        self._song_kana_map: list[dict] = self._load_json_safe(self._song_kana_map_path)
        self._video_metadata: list[dict] = self._load_json_safe(self._cfg.video_metadata_path)
        self._song_kana_lock = threading.Lock()
        self._title_to_indices: dict[str, list[int]] = self._build_title_to_indices()
        self._sorted_titles: list[str] = sorted(self._title_to_indices.keys(), key=len, reverse=True)
        # カナ変換用: (原文キー小文字, カナ値, エントリインデックス, kind) を長さ降順でソート
        self._kana_rules: list[tuple[str, str, int, str]] = self._build_kana_rules()

    @staticmethod
    def _load_json_safe(path: Optional[Path]) -> list:
        if path is None:
            return []
        try:
            if (not path.exists()) or (not path.is_file()):
                return []
        except Exception:
            return []
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            return data if isinstance(data, list) else []
        except Exception:
            return []

    def _build_kana_rules(self) -> list[tuple[str, str, int, str, str]]:
        # song_kana_map の title→index テーブル（play_count追跡用）
        title_to_idx: dict[str, int] = {}
        for i, entry in enumerate(self._song_kana_map):
            t = entry.get("title", "").lower()
            if t and t not in title_to_idx:
                title_to_idx[t] = i

        # カナはvideo_metadata.jsonから取得（song_kana_mapにはカナフィールドなし）
        # tuple: (key_lower, kana_value, idx, kind, original_text)
        rules = []
        seen: set[str] = set()
        for entry in self._video_metadata:
            artist = entry.get("artist", "")
            artist_kana = entry.get("artist_kana", "")
            title = entry.get("title", "")
            title_kana = entry.get("title_kana", "")
            title_lower = title.lower()
            idx = title_to_idx.get(title_lower, -1)
            if artist and artist_kana and artist.lower() not in seen:
                seen.add(artist.lower())
                rules.append((artist.lower(), artist_kana, idx, "artist", artist))
            if title and title_kana and title_lower not in seen:
                seen.add(title_lower)
                rules.append((title_lower, title_kana, idx, "title", title))
        # 長い文字列を優先してマッチ
        rules.sort(key=lambda r: len(r[0]), reverse=True)
        return rules

    def _build_title_to_indices(self) -> dict[str, list[int]]:
        title_to_indices: dict[str, list[int]] = {}
        for i, entry in enumerate(self._song_kana_map):
            title = str(entry.get("title", "")).strip().lower()
            if not title:
                continue
            title_to_indices.setdefault(title, []).append(i)
        return title_to_indices

    def _append_sbv2_log_tail(self, line: str) -> None:
        stamp = datetime.now().strftime("%H:%M:%S")
        with self._sbv2_log_lock:
            self._sbv2_log_tail.append(f"{stamp} {line}")

    def _emit_sbv2_diagnostics(self, reason: str) -> None:
        proc = self._sbv2_proc
        url = (self._cfg.sbv2_server_url or "").strip() or "(empty)"
        if proc is None:
            self.log.emit(f"[sbv2-diag] reason={reason} proc=none url={url}")
        else:
            rc = proc.poll()
            state = f"running(pid={proc.pid})" if rc is None else f"exited(pid={proc.pid}, rc={rc})"
            self.log.emit(f"[sbv2-diag] reason={reason} proc={state} url={url}")
        if self._sbv2_last_exit_code is not None:
            self.log.emit(
                f"[sbv2-diag] last_exit code={self._sbv2_last_exit_code} at={self._sbv2_last_exit_at or '(unknown)'}"
            )
        with self._sbv2_log_lock:
            tail = list(self._sbv2_log_tail)[-30:]
        if tail:
            self.log.emit(f"[sbv2-diag] tail_lines={len(tail)}")
            for ln in tail:
                self.log.emit(f"[sbv2-diag] {ln}")

    @staticmethod
    def _strip_video_payload_prefix(text: str) -> str:
        # タイトル前に付きやすい装飾記号だけを除去する
        return (text or "").strip().lstrip(" 　「『\"'（([【<♡♥❤💗💖💓…。.、,:：;；!-")

    def stop(self) -> None:
        self._running = False
        if self._observer is not None:
            self._observer.stop()
        self._stop_external_text_server()
        if self._transcribe_proc is not None:
            try:
                self._transcribe_proc.terminate()
            except Exception:
                pass
            self._transcribe_proc = None
        if self._sbv2_proc is not None:
            try:
                self._sbv2_proc.terminate()
            except Exception:
                pass
            self._sbv2_proc = None
        with self._proc_lock:
            if self._current_proc is not None:
                try:
                    self._current_proc.terminate()
                except Exception:
                    pass

    def pause(self) -> None:
        self._paused = True
        # 保留中のWAVを全て破棄
        drained = 0
        while not self._wav_queue.empty():
            try:
                self._wav_queue.get_nowait()
                drained += 1
            except queue.Empty:
                break
        try:
            self.log.emit(f"[pause] WAVキュー破棄: {drained}件")
        except RuntimeError:
            pass

    def resume(self) -> None:
        self._paused = False
        try:
            self.log.emit("[resume] 再開")
        except RuntimeError:
            pass

    def send_text(self, text: str) -> None:
        try:
            self._text_queue.put_nowait(text)
        except queue.Full:
            self.log.emit("[warn] テキストキューが満杯")

    def _source_mode(self) -> str:
        mode = (self._cfg.source_mode or DEFAULT_SOURCE_MODE).strip().lower()
        if mode not in ("external", "mic", "both"):
            return DEFAULT_SOURCE_MODE
        return mode

    @staticmethod
    def _normalize_endpoint(endpoint: str) -> str:
        value = (endpoint or "").strip()
        if not value:
            return "/manual-text"
        if not value.startswith("/"):
            return "/" + value
        return value

    def _register_external_event_id(self, event_id: str) -> bool:
        if not event_id:
            return True

        key = event_id.strip()
        if not key:
            return True

        max_ids = max(10, int(self._cfg.external_text_dedupe_max))
        with self._external_lock:
            if key in self._external_id_set:
                return False
            self._external_id_set.add(key)
            self._external_id_queue.append(key)
            while len(self._external_id_queue) > max_ids:
                old = self._external_id_queue.popleft()
                self._external_id_set.discard(old)
        return True

    def _accept_external_text(self, text: str, event_id: str, source: str) -> tuple[bool, str, int]:
        mode = self._source_mode()
        if mode == "mic":
            return False, "source_mode=mic", int(HTTPStatus.CONFLICT)

        normalized = (text or "").strip()
        if not normalized:
            return False, "text is empty", int(HTTPStatus.BAD_REQUEST)

        if not self._register_external_event_id(event_id):
            return False, "duplicate event_id", int(HTTPStatus.CONFLICT)

        try:
            self._text_queue.put_nowait(normalized)
        except queue.Full:
            return False, "text queue is full", int(HTTPStatus.SERVICE_UNAVAILABLE)

        src = (source or "external").strip() or "external"
        self.log.emit(f"[external] queued source={src} text={normalized[:80]}")
        return True, "", int(HTTPStatus.OK)

    def _start_external_text_server(self) -> None:
        if not self._cfg.external_text_enabled:
            self.log.emit("[external] disabled")
            return

        mode = self._source_mode()
        if mode == "mic":
            self.log.emit("[external] source_mode=mic のため受信サーバーを起動しません")
            return

        endpoint = self._normalize_endpoint(self._cfg.external_text_endpoint)
        host = (self._cfg.external_text_host or "127.0.0.1").strip() or "127.0.0.1"
        port = max(1, min(65535, int(self._cfg.external_text_port)))
        token = (self._cfg.external_text_token or "").strip()
        owner = self

        class Handler(BaseHTTPRequestHandler):
            def _write_json(self, status: int, payload: dict[str, Any]) -> None:
                raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
                self.send_response(status)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)

            def do_GET(self) -> None:
                if self.path != "/health":
                    self._write_json(int(HTTPStatus.NOT_FOUND), {"ok": False, "error": "not found"})
                    return
                self._write_json(
                    int(HTTPStatus.OK),
                    {"ok": True, "mode": owner._source_mode(), "endpoint": endpoint},
                )

            def do_POST(self) -> None:
                if self.path != endpoint:
                    self._write_json(int(HTTPStatus.NOT_FOUND), {"ok": False, "error": "not found"})
                    return

                if token:
                    req_token = (self.headers.get("X-Auth-Token") or "").strip()
                    if req_token != token:
                        self._write_json(int(HTTPStatus.FORBIDDEN), {"ok": False, "error": "forbidden"})
                        return

                try:
                    length = int(self.headers.get("Content-Length", "0"))
                except Exception:
                    length = 0
                if length <= 0:
                    self._write_json(int(HTTPStatus.BAD_REQUEST), {"ok": False, "error": "empty body"})
                    return

                raw = self.rfile.read(length)
                try:
                    payload = json.loads(raw.decode("utf-8"))
                except Exception:
                    self._write_json(int(HTTPStatus.BAD_REQUEST), {"ok": False, "error": "invalid json"})
                    return

                if not isinstance(payload, dict):
                    self._write_json(int(HTTPStatus.BAD_REQUEST), {"ok": False, "error": "payload must be object"})
                    return

                text = str(payload.get("text", "")).strip()
                event_id = str(payload.get("event_id", "")).strip()
                source = str(payload.get("source", "external")).strip()

                ok, reason, status = owner._accept_external_text(text, event_id, source)
                if ok:
                    self._write_json(status, {"ok": True, "queued": True})
                else:
                    self._write_json(status, {"ok": False, "error": reason})

            def log_message(self, fmt: str, *args: Any) -> None:
                owner.log.emit("[external-http] " + (fmt % args))

        try:
            server = ThreadingHTTPServer((host, port), Handler)
        except Exception as exc:
            self.log.emit(f"[external] 起動失敗: {exc}")
            return

        server.daemon_threads = True
        server.timeout = 0.5
        self._external_server = server
        self._external_server_thread = threading.Thread(
            target=server.serve_forever,
            kwargs={"poll_interval": 0.5},
            daemon=True,
        )
        self._external_server_thread.start()
        self.log.emit(f"[external] listening http://{host}:{port}{endpoint}")

    def _stop_external_text_server(self) -> None:
        if self._external_server is not None:
            try:
                self._external_server.shutdown()
            except Exception:
                pass
            try:
                self._external_server.server_close()
            except Exception:
                pass
            self._external_server = None

        if self._external_server_thread is not None:
            self._external_server_thread.join(timeout=2.0)
            self._external_server_thread = None

    @pyqtSlot()
    def run(self) -> None:
        try:
            self.log.emit("[pipeline] フォルダ作成中...")
            self._cfg.wav_dir.mkdir(parents=True, exist_ok=True)
            for sub in (
                "transcripts",
                "responses",
                "results",
                "grok_tts_outputs",
                "source_wavs",
                "sbv2_inputs",
                "sbv2_wavs",
            ):
                (self._cfg.output_dir / sub).mkdir(parents=True, exist_ok=True)
            self.log.emit(f"[pipeline] フォルダOK: wav={self._cfg.wav_dir}, out={self._cfg.output_dir}")

            self.log.emit("[pipeline] transcribeサーバー起動中...")
            self._start_transcribe_server()
            self.log.emit("[pipeline] transcribeサーバーOK")

            self.log.emit("[pipeline] SBV2サーバー起動中...")
            self._start_sbv2_server()
            self.log.emit("[pipeline] SBV2サーバーOK")

            self.log.emit("[pipeline] 外部テキストサーバー起動中...")
            self._start_external_text_server()
            self.log.emit("[pipeline] 外部テキストサーバーOK")

            self.log.emit("[pipeline] ファイル監視起動中...")
            self._observer = self._create_observer()
            self._observer.start()
            self.log.emit(f"[pipeline] 全起動完了 — 監視開始: {self._cfg.wav_dir}")

            while self._running:
                # 手動テキスト優先
                try:
                    text = self._text_queue.get_nowait()
                    raw_text = str(text or "").strip()
                    if not raw_text:
                        continue
                    text_grok = self._apply_transcribe_conversion(raw_text, mode="grok")
                    text_display = self._apply_transcribe_conversion(raw_text, mode="display")
                    if text_grok != raw_text:
                        self.log.emit(f"[manual-conv] grok: '{raw_text}' -> '{text_grok}'")
                    if text_display != raw_text:
                        self.log.emit(f"[manual-conv] display: '{raw_text}' -> '{text_display}'")
                    if self._cfg.save_fasterwhisper_text:
                        stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]
                        saved = self._save_text_file(
                            self._cfg.output_dir / "transcripts" / f"{stamp}.txt",
                            raw_text + "\n",
                        )
                        if saved is not None:
                            self.log.emit(f"[save] manual_text: {saved}")
                    self._process_text(text_grok, manual=True, display_text=text_display)
                except queue.Empty:
                    pass

                # WAVキュー
                try:
                    wav = self._wav_queue.get(timeout=0.3)
                    if self._paused:
                        self.log.emit(f"[pause] 破棄: {wav.name}")
                    elif self._source_mode() == "external":
                        self.log.emit(f"[source_mode] external: WAV無視 {wav.name}")
                        try:
                            wav.unlink(missing_ok=True)
                        except Exception:
                            pass
                    else:
                        self._process_wav(wav)
                except queue.Empty:
                    pass

        except Exception:
            tb = traceback.format_exc()
            self.log.emit(f"[pipeline] ★致命的エラーで停止:\n{tb}")
            self.error.emit(tb)
        finally:
            self.log.emit("[pipeline] 終了処理開始...")
            if self._observer is not None:
                self._observer.stop()
                self._observer.join(timeout=3.0)
            self._stop_external_text_server()
            self.log.emit("[pipeline] パイプライン停止完了")
            self.finished.emit()

    def _create_observer(self):
        from watchdog.events import FileSystemEventHandler
        from watchdog.observers import Observer

        owner = self

        class Handler(FileSystemEventHandler):
            def on_created(self, event):
                if not event.is_directory:
                    owner._enqueue(Path(event.src_path))
            def on_moved(self, event):
                if not event.is_directory:
                    owner._enqueue(Path(event.dest_path))

        obs = Observer()
        obs.schedule(Handler(), str(self._cfg.wav_dir), recursive=False)
        return obs

    def _enqueue(self, path: Path) -> None:
        if path.suffix.lower() != ".wav":
            return
        if self._source_mode() == "external":
            return
        key = str(path.resolve())
        with self._lock:
            if key in self._seen:
                return
            self._seen.add(key)
        try:
            self._wav_queue.put_nowait(path)
        except queue.Full:
            self.log.emit(f"[warn] WAVキュー満杯: {path.name}")

    def _wait_stable(self, path: Path) -> bool:
        stable, last_size, start = 0, -1, time.time()
        while self._running and not self._paused and (time.time() - start) < 30.0:
            if not path.exists():
                stable = 0; last_size = -1; time.sleep(0.25); continue
            size = path.stat().st_size
            if size > 0 and size == last_size:
                stable += 1
                if stable >= 3:
                    return True
            else:
                stable = 0; last_size = size
            time.sleep(0.25)
        return False

    def _is_filtered(self, text: str) -> bool:
        lower = text.lower()
        return any(p.strip() and p.strip().lower() in lower for p in self._cfg.filter_phrases)

    def _run_cmd(self, cmd: list[str], timeout_sec: float) -> subprocess.CompletedProcess:
        proc = subprocess.Popen(
            cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, encoding="utf-8", errors="replace",
            env=_with_utf8_env(),
        )
        with self._proc_lock:
            self._current_proc = proc
        try:
            stdout, stderr = proc.communicate(timeout=timeout_sec)
        except subprocess.TimeoutExpired:
            proc.terminate()
            stdout, stderr = proc.communicate()
        finally:
            with self._proc_lock:
                self._current_proc = None
        return subprocess.CompletedProcess(cmd, proc.returncode, stdout, stderr)

    def _resolve_scripts(self) -> tuple[Path, Path]:
        # ローカル同梱スクリプトを優先、なければ従来のkks_rootパスにフォールバック
        local_root = PROJECT_ROOT
        transcribe = local_root / "run_transcribe_one_wav.py"
        tts_event = local_root / "run_grok_tts_event.py"
        if transcribe.exists() and tts_event.exists():
            return transcribe, tts_event
        root = self._cfg.kks_root / "work" / "tools" / "grok_bridge"
        return (root / "run_transcribe_one_wav.py").resolve(), (root / "run_grok_tts_event.py").resolve()

    def _transcribe_server_url(self) -> str:
        return f"http://127.0.0.1:{self._cfg.transcribe_server_port}"

    def _start_transcribe_server(self) -> None:
        health_url = f"{self._transcribe_server_url()}/health"

        # 既存サーバーが起動済みなら再利用
        try:
            with urllib.request.urlopen(health_url, timeout=2.0):
                self.log.emit("[server] 既存転写サーバーを再利用")
                return
        except Exception:
            pass

        local_root = PROJECT_ROOT
        server_script = local_root / "run_transcribe_server.py"
        if not server_script.exists():
            root = self._cfg.kks_root / "work" / "tools" / "grok_bridge"
            server_script = (root / "run_transcribe_server.py").resolve()
        cmd = [
            str(self._cfg.faster_python), str(server_script),
            "--model", self._cfg.faster_model,
            "--device", self._cfg.faster_device,
            "--compute-type", self._cfg.faster_compute,
            "--language", self._cfg.faster_language,
            "--beam-size", str(self._cfg.faster_beam),
            "--port", str(self._cfg.transcribe_server_port),
        ]
        self.log.emit(f"[server] 転写サーバー起動中 ({self._cfg.faster_model}) ...")
        self._transcribe_proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, encoding="utf-8", errors="replace",
            env=_with_utf8_env(),
        )

        # stdout をバックグラウンドスレッドでログに転送
        proc = self._transcribe_proc
        log_emit = self.log.emit
        def _forward():
            try:
                for line in proc.stdout:
                    line = line.rstrip()
                    if line:
                        log_emit(line)
            except Exception:
                pass
        threading.Thread(target=_forward, daemon=True).start()

        # サーバーが Ready になるまで待機（モデルロード時間を考慮して最大90秒）
        deadline = time.time() + 90.0
        while time.time() < deadline and self._running:
            if proc.poll() is not None:
                raise RuntimeError("転写サーバーが異常終了しました")
            try:
                with urllib.request.urlopen(health_url, timeout=1.0):
                    self.log.emit("[server] 転写サーバー Ready")
                    return
            except Exception:
                time.sleep(1.0)
        raise RuntimeError("転写サーバーの起動タイムアウト (90秒)")

    def _start_sbv2_server(self) -> None:
        if not self._cfg.sbv2_server_auto_start:
            return
        health_url = self._cfg.sbv2_server_url.rstrip("/") + "/models/info"
        try:
            with urllib.request.urlopen(health_url, timeout=2.0):
                self.log.emit("[sbv2] 既存SBV2サーバーを再利用")
                return
        except Exception:
            pass

        sbv2_root = self._cfg.sbv2_root
        sbv2_python = sbv2_root / "venv" / "Scripts" / "python.exe"
        if not sbv2_python.exists():
            self.log.emit(f"[sbv2] python not found: {sbv2_python} → 手動起動してください")
            return

        server_script = sbv2_root / "server_fastapi.py"
        if not server_script.exists():
            self.log.emit(f"[sbv2] server_fastapi.py not found: {server_script}")
            return

        self.log.emit("[sbv2] SBV2サーバー起動中 (モデルロードに数十秒かかります) ...")
        self._sbv2_proc = subprocess.Popen(
            [str(sbv2_python), str(server_script)],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, encoding="utf-8", errors="replace",
            env=_with_utf8_env(),
            cwd=str(sbv2_root),
        )

        proc = self._sbv2_proc
        log_emit = self.log.emit
        def _forward():
            try:
                for line in proc.stdout:
                    line = line.rstrip()
                    if line:
                        self._append_sbv2_log_tail(line)
                        log_emit(f"[sbv2] {line}")
            except Exception:
                pass
            finally:
                rc = proc.poll()
                if rc is not None:
                    self._sbv2_last_exit_code = rc
                    self._sbv2_last_exit_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    if self._running:
                        log_emit(f"[sbv2] server process exited rc={rc}")
                        self._emit_sbv2_diagnostics("stdout_closed")
        threading.Thread(target=_forward, daemon=True).start()

        deadline = time.time() + 300.0
        while time.time() < deadline and self._running:
            if proc.poll() is not None:
                self._sbv2_last_exit_code = proc.poll()
                self._sbv2_last_exit_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                self._emit_sbv2_diagnostics("start_wait_exited")
                raise RuntimeError("SBV2サーバーが異常終了しました")
            try:
                with urllib.request.urlopen(health_url, timeout=1.0):
                    self.log.emit("[sbv2] SBV2サーバー Ready")
                    return
            except Exception:
                time.sleep(1.0)
        self._emit_sbv2_diagnostics("start_wait_timeout")
        raise RuntimeError("SBV2サーバーの起動タイムアウト (300秒)")

    def _transcribe_via_server(self, wav: Path) -> dict:
        url = f"{self._transcribe_server_url()}/transcribe"
        payload = json.dumps({
            "audio": str(wav),
            "language": self._cfg.faster_language,
            "beam_size": self._cfg.faster_beam,
        }, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(url, data=payload, method="POST")
        req.add_header("Content-Type", "application/json; charset=utf-8")
        with urllib.request.urlopen(req, timeout=120.0) as resp:
            return json.loads(resp.read().decode("utf-8"))

    @staticmethod
    def _unique_output_path(path: Path) -> Path:
        if not path.exists():
            return path
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]
        return path.with_name(f"{path.stem}_{stamp}{path.suffix}")

    def _save_text_file(self, path: Path, text: str) -> Optional[Path]:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            out = self._unique_output_path(path)
            out.write_text(text, encoding="utf-8")
            return out
        except Exception as exc:
            self.log.emit(f"[warn] テキスト保存失敗: {path} ({exc})")
            return None

    def _copy_output_file(self, src: Path, dst_dir: Path, *, out_name: Optional[str] = None) -> Optional[Path]:
        try:
            if not src.exists() or not src.is_file():
                return None
            dst_dir.mkdir(parents=True, exist_ok=True)
            target = dst_dir / (out_name or src.name)
            target = self._unique_output_path(target)
            shutil.copy2(src, target)
            return target
        except Exception as exc:
            self.log.emit(f"[warn] ファイル保存失敗: {src} -> {dst_dir} ({exc})")
            return None

    def _process_wav(self, wav: Path) -> None:
        if not self._wait_stable(wav):
            self.log.emit(f"[warn] 不安定/一時停止のためスキップ: {wav.name}")
            return
        if self._paused:
            self.log.emit(f"[pause] 破棄: {wav.name}")
            return

        try:
            self.log.emit(f"[transcribe] {wav.name}")
            t_json = self._transcribe_via_server(wav)
            if not t_json.get("ok"):
                raise RuntimeError(str(t_json.get("error", "transcribe failed")))
            text = str(t_json.get("text", "")).strip()
            if not text:
                self.log.emit(f"[info] 空テキスト: {wav.name}")
                return
            raw_text = text
            text = self._apply_transcribe_conversion(raw_text, mode="grok")
            display_text = self._apply_transcribe_conversion(raw_text, mode="display")
            if not text:
                self.log.emit(f"[info] 変換後に空テキスト: {wav.name}")
                return
            if self._cfg.save_fasterwhisper_text:
                saved_transcript = self._save_text_file(
                    self._cfg.output_dir / "transcripts" / f"{wav.stem}.txt",
                    raw_text + "\n",
                )
                if saved_transcript is not None:
                    self.log.emit(f"[save] whisper_text: {saved_transcript}")

            if self._paused:
                self.log.emit(f"[pause] 破棄: {text[:40]}")
                return
            if self._is_filtered(text):
                self.log.emit(f"[filter] 除外: {text[:60]}")
                return
            self._process_text(text, wav=wav, display_text=display_text)
        except Exception as exc:
            self.log.emit(f"[error] {wav.name}: {exc}")
        finally:
            if self._cfg.save_source_wav:
                saved_wav = self._copy_output_file(
                    wav,
                    self._cfg.output_dir / "source_wavs",
                )
                if saved_wav is not None:
                    self.log.emit(f"[save] source_wav: {saved_wav}")
            try:
                wav.unlink(missing_ok=True)
            except Exception:
                pass

    def update_transcribe_conv(self, rules: list[dict]) -> None:
        with self._transcribe_conv_lock:
            self._transcribe_conv_rules = list(rules or [])

    def update_runtime_config(self, cfg: AppConfig) -> None:
        prev_video_metadata = self._cfg.video_metadata_path
        self._cfg = cfg
        self.update_transcribe_conv(cfg.transcribe_conversion_dict)
        if prev_video_metadata != cfg.video_metadata_path:
            with self._song_kana_lock:
                self._video_metadata = self._load_json_safe(cfg.video_metadata_path)
                self._title_to_indices = self._build_title_to_indices()
                self._sorted_titles = sorted(self._title_to_indices.keys(), key=len, reverse=True)
                self._kana_rules = self._build_kana_rules()
            self.log.emit(f"[live] video_metadata reloaded: {cfg.video_metadata_path or '(none)'}")

    def _apply_transcribe_conversion(self, text: str, mode: str = "grok") -> str:
        converted = text
        applied = 0
        with self._transcribe_conv_lock:
            rules = list(self._transcribe_conv_rules)
        target = "display" if str(mode).strip().lower() == "display" else "grok"
        for row in rules:
            if not isinstance(row, dict):
                continue
            src = str(row.get("from", ""))
            if not src:
                continue
            if target == "display":
                if not bool(row.get("display_apply", True)):
                    continue
                if "to_display" in row:
                    dst = str(row.get("to_display", ""))
                elif "to" in row:
                    # backward compatible with old schema
                    dst = str(row.get("to", ""))
                else:
                    dst = str(row.get("to_grok", ""))
            else:
                if "to_grok" in row:
                    dst = str(row.get("to_grok", ""))
                elif "to" in row:
                    # backward compatible with old schema
                    dst = str(row.get("to", ""))
                else:
                    dst = str(row.get("to_display", ""))
            hit = converted.count(src)
            if hit <= 0:
                continue
            converted = converted.replace(src, dst)
            applied += 1
            tag = "stt-conv-display" if target == "display" else "stt-conv-grok"
            self.log.emit(f"[{tag}] '{src}' -> '{dst}' (hits={hit})")
        if applied > 0:
            tag = "stt-conv-display" if target == "display" else "stt-conv-grok"
            self.log.emit(f"[{tag}] applied_rules={applied}")
        return converted

    def _post_json(self, host: str, port: int, endpoint: str, token: str,
                   payload: dict, timeout_sec: float) -> tuple[bool, str]:
        ep = ("/" + endpoint.strip().lstrip("/")) if endpoint.strip() else "/"
        url = f"http://{host}:{port}{ep}"
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(url=url, data=body, method="POST")
        req.add_header("Content-Type", "application/json; charset=utf-8")
        if token:
            req.add_header("X-Auth-Token", token)
        try:
            with urllib.request.urlopen(req, timeout=max(0.1, timeout_sec)) as resp:
                return True, resp.read().decode("utf-8", errors="replace").strip()
        except urllib.error.HTTPError as exc:
            try:
                detail = exc.read().decode("utf-8", errors="replace")
            except Exception:
                detail = ""
            return False, f"HTTP {exc.code}: {detail}"
        except Exception as exc:
            return False, str(exc)

    def _send_subtitle(self, text: str, wav_name: str, mode: str, hold_seconds: Optional[float] = None) -> None:
        if not self._cfg.subtitle_send_enabled:
            return
        host = self._cfg.subtitle_target_host or "127.0.0.1"
        text_payload = text
        if mode.lower() == "stackfemale":
            t = text.strip()
            if t and "<color=" not in t.lower():
                text_payload = f"<color=#FF7ACDFF>{t}</color>"
        payload = {"text": text_payload, "source": "human2kks", "wav_name": wav_name, "display_mode": mode}
        if hold_seconds is not None:
            payload["hold_seconds"] = hold_seconds
        ok, detail = self._post_json(
            host, self._cfg.subtitle_target_port,
            self._cfg.subtitle_endpoint, self._cfg.subtitle_token,
            payload,
            self._cfg.subtitle_timeout_sec,
        )
        if not ok:
            self.log.emit(f"[subtitle] 失敗: {detail}")

    def _apply_kana_conversion(self, text: str) -> tuple[str, list[int]]:
        """テキスト中のartist/titleをカナに変換し、マッチしたsong_kana_mapのインデックス一覧を返す"""
        result = text
        matched_indices: list[int] = []
        for key_lower, kana_value, idx, _kind in self._kana_rules:
            search_pos = 0
            lower_result = result.lower()
            while True:
                pos = lower_result.find(key_lower, search_pos)
                if pos < 0:
                    break
                original = result[pos:pos + len(key_lower)]
                result = result[:pos] + kana_value + result[pos + len(key_lower):]
                lower_result = result.lower()
                search_pos = pos + len(kana_value)
                if idx not in matched_indices:
                    matched_indices.append(idx)
        return result, matched_indices

    def _find_video_indices_from_response(self, response: str) -> list[int]:
        """Grokレスポンスから動画切り替えトリガーを検出してsong_kana_mapのインデックスを返す"""
        if not response:
            return []

        trigger_match = re.search(r"今から(?:もう一度|もう一回|また)?流すね[♡♥❤💗💖💓…\.\s]*", response)
        if not trigger_match:
            return []

        payload = response[trigger_match.end():].splitlines()[0].strip()
        if not payload:
            return []

        payload_candidates = [
            payload,
            self._strip_video_payload_prefix(payload),
        ]

        # 1) タイトル前方一致（最も厳密）を優先
        for candidate in payload_candidates:
            candidate_lower = candidate.lower()
            for title_lower in self._sorted_titles:
                if candidate_lower.startswith(title_lower):
                    indices = self._title_to_indices.get(title_lower, [])
                    self.log.emit(f"[video] トリガー検出(前方一致): '{payload}' -> title='{title_lower}' indices={indices}")
                    return indices

        # 2) 先頭付近の部分一致（「今から流すね♡ TITLE♡ 〜」を拾うため）
        best_title = ""
        best_pos = 9999
        for candidate in payload_candidates:
            candidate_lower = candidate.lower()
            for title_lower in self._sorted_titles:
                pos = candidate_lower.find(title_lower)
                if pos < 0 or pos > 24:
                    continue
                if pos < best_pos or (pos == best_pos and len(title_lower) > len(best_title)):
                    best_pos = pos
                    best_title = title_lower

        if best_title:
            indices = self._title_to_indices.get(best_title, [])
            self.log.emit(f"[video] トリガー検出(近傍一致): '{payload}' -> title='{best_title}' indices={indices}")
            return indices

        self.log.emit(f"[video] トリガー検出失敗: '{payload}'")
        return []

    def _schedule_response_text(self, text: str, main_index: int, delay_sec: float) -> None:
        """Grokの生テキストをそのままKKSへ送る（C#側でキーワードマッチ）"""
        sender_ps1 = Path(__file__).resolve().parent.parent / "send_voice_face_event.ps1"
        pipe_name = self._cfg.pipe_name
        target_host = self._cfg.target_host.strip()
        remote_http = self._cfg.remote_http
        target_port = self._cfg.target_port
        target_endpoint = self._cfg.target_endpoint
        running_ref = lambda: self._running

        def _send():
            if not running_ref():
                return
            payload = json.dumps(
                {"type": "response_text", "text": text, "main": main_index, "delaySeconds": delay_sec or 0.0},
                ensure_ascii=False
            )
            cmd = [
                "powershell", "-ExecutionPolicy", "Bypass", "-File", str(sender_ps1),
                "-PipeName", pipe_name,
                "-Json", payload,
            ]
            if remote_http or target_host:
                cmd.append("-RemoteHttp")
            if target_host:
                cmd.extend(["-TargetHost", target_host,
                             "-TargetPort", str(target_port),
                             "-TargetEndpoint", target_endpoint])
            try:
                result = subprocess.run(cmd, capture_output=True, text=True,
                                        encoding="utf-8", errors="replace", timeout=10,
                                        env=_with_utf8_env())
                if result.returncode != 0:
                    self.log.emit(f"[response_text] pipe送信失敗: {(result.stderr or result.stdout or '').strip()}")
                else:
                    self.log.emit(f"[response_text] 送信完了")
            except Exception as e:
                self.log.emit(f"[response_text] pipe送信例外: {e}")

        threading.Thread(target=_send, daemon=True).start()

    def _increment_play_counts(self, indices: list[int]) -> None:
        """song_kana_mapのplay_countをインクリメントしてファイルに書き戻す"""
        if not indices:
            return
        if not self._song_kana_map:
            return
        with self._song_kana_lock:
            for idx in indices:
                if 0 <= idx < len(self._song_kana_map):
                    self._song_kana_map[idx]["play_count"] = self._song_kana_map[idx].get("play_count", 0) + 1
            try:
                self._song_kana_map_path.parent.mkdir(parents=True, exist_ok=True)
                self._song_kana_map_path.write_text(
                    json.dumps(self._song_kana_map, ensure_ascii=False, indent=2),
                    encoding="utf-8"
                )
            except Exception as e:
                self.log.emit(f"[warn] song_kana_map 書き込み失敗: {e}")

    def _schedule_video_switch(self, matched_indices: list[int], delay_sec: float) -> None:
        """delay_sec秒後にKKSへ動画切り替え信号を送るバックグラウンドスレッドを起動"""
        if not matched_indices:
            return

        # マッチしたタイトル一覧を収集（重複除去）
        titles = []
        seen_titles: set[str] = set()
        for idx in matched_indices:
            if 0 <= idx < len(self._song_kana_map):
                t = self._song_kana_map[idx].get("title", "")
                if t and t not in seen_titles:
                    titles.append(t)
                    seen_titles.add(t)

        if not titles:
            return

        chosen_title = random.choice(titles)

        # video_metadata.json から同タイトルの全ファイルを取得
        candidates = [
            e["file"] for e in self._video_metadata
            if e.get("title", "").lower() == chosen_title.lower() and e.get("file", "")
        ]
        if not candidates:
            self.log.emit(f"[video] タイトル '{chosen_title}' に一致する動画なし")
            return

        chosen_file = random.choice(candidates)

        def _send():
            if delay_sec and delay_sec > 0:
                time.sleep(delay_sec)
            if not self._running:
                return
            payload = json.dumps({"filename": chosen_file}, ensure_ascii=False).encode("utf-8")
            req = urllib.request.Request(
                "http://127.0.0.1:55982/videoroom/play",
                data=payload, method="POST"
            )
            req.add_header("Content-Type", "application/json; charset=utf-8")
            try:
                with urllib.request.urlopen(req, timeout=5.0):
                    pass
                self.log.emit(f"[video] 切替 → {chosen_file} (title: {chosen_title})")
            except Exception as e:
                self.log.emit(f"[video] KKS送信失敗: {e}")

        threading.Thread(target=_send, daemon=True).start()

    def _process_text(self, text: str, wav: Optional[Path] = None, manual: bool = False, display_text: Optional[str] = None) -> None:
        _, pipeline_script = self._resolve_scripts()
        wav_name = wav.name if wav else "manual"
        # 字幕は元テキストのまま送る
        self._send_subtitle(display_text if display_text is not None else text, wav_name, "StackMale")

        # カナ変換ルールをconversion_jsonとして渡す（Grokレスポンスに適用される）
        kana_conv = [{"from": r[4], "to": r[1]} for r in self._kana_rules if r[4] and r[1]]
        combined_conv = kana_conv + list(self._cfg.conversion_dict or [])

        p_cmd = [
            str(self._cfg.pipeline_python), str(pipeline_script),
            "--text", text,
            "--sbv2-root", str(self._cfg.sbv2_root),
            "--model-name", self._cfg.sbv2_model_name,
            "--speaker", self._cfg.sbv2_speaker,
            "--style", self._cfg.sbv2_style,
            "--length", str(self._cfg.sbv2_length),
            "--output-dir", str(self._cfg.output_dir / "grok_tts_outputs"),
            "--pipe-name", self._cfg.pipe_name,
            "--main", str(self._cfg.main_index),
        ]
        if self._cfg.voice_volume >= 0:
            p_cmd.extend(["--voice-volume", str(self._cfg.voice_volume)])
        if self._cfg.voice_pitch >= 0:
            p_cmd.extend(["--voice-pitch", str(self._cfg.voice_pitch)])
        target_host = self._cfg.target_host.strip()
        if self._cfg.remote_http and target_host:
            p_cmd.append("--remote-http")
        if target_host:
            p_cmd.extend(["--target-host", target_host,
                           "--target-port", str(self._cfg.target_port),
                           "--target-endpoint", self._cfg.target_endpoint])
            if self._cfg.target_token:
                p_cmd.extend(["--target-token", self._cfg.target_token])
        if self._cfg.sbv2_model_file:
            p_cmd.extend(["--model-file", self._cfg.sbv2_model_file])
        if self._cfg.sbv2_server_url:
            p_cmd.extend(["--sbv2-server-url", self._cfg.sbv2_server_url])
        if combined_conv:
            p_cmd.extend(["--conversion-json", json.dumps(combined_conv, ensure_ascii=False)])
        if self._cfg.grok_detection_mode and self._cfg.grok_detection_mode != "stop_button":
            p_cmd.extend(["--detection-mode", self._cfg.grok_detection_mode])
            if self._cfg.grok_text_stable_seconds > 0:
                p_cmd.extend(["--text-stable-seconds", str(self._cfg.grok_text_stable_seconds)])
        # event-senderは同梱スクリプトを明示指定
        sender_ps1 = Path(__file__).resolve().parent.parent / "send_voice_face_event.ps1"
        if sender_ps1.exists():
            p_cmd.extend(["--event-sender", str(sender_ps1)])
        if self._cfg.keep_current_face:
            p_cmd.append("--keep-current-face")
        elif self._cfg.face >= 0:
            p_cmd.extend(["--face", str(self._cfg.face)])

        label = "手動" if manual else wav_name
        self.log.emit(f"[pipeline] {label}: {text[:40]}")
        try:
            p_ret = self._run_cmd(p_cmd, timeout_sec=420.0)
            if p_ret.returncode != 0:
                raise RuntimeError((p_ret.stderr or p_ret.stdout or "").strip())
            for ln in (p_ret.stdout or "").splitlines():
                if "conversion_" in ln:
                    self.log.emit(f"[tts-conv] {ln}")
            p_json = _last_json_line(p_ret.stdout)
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")[:-3]
            merged_wav_raw = str(p_json.get("merged_wav", "")).strip()
            merged_wav_path = Path(merged_wav_raw) if merged_wav_raw else None
            run_dir = merged_wav_path.parent if merged_wav_path is not None else None

            if self._cfg.save_sbv2_input_text:
                sbv2_input_text = ""
                line_texts = p_json.get("line_texts", [])
                if isinstance(line_texts, list):
                    lines = [str(v).strip() for v in line_texts if str(v).strip()]
                    if lines:
                        sbv2_input_text = "\n".join(lines)
                if not sbv2_input_text:
                    sbv2_input_text = str(p_json.get("response", "")).strip()
                if sbv2_input_text:
                    saved_sbv2_input = self._save_text_file(
                        self._cfg.output_dir / "sbv2_inputs" / f"{stamp}.txt",
                        sbv2_input_text + "\n",
                    )
                    if saved_sbv2_input is not None:
                        p_json["sbv2_input_file"] = str(saved_sbv2_input)
                        self.log.emit(f"[save] sbv2_input_text: {saved_sbv2_input}")

            if self._cfg.save_sbv2_output_wav and merged_wav_path is not None:
                saved_sbv2_wav = self._copy_output_file(
                    merged_wav_path,
                    self._cfg.output_dir / "sbv2_wavs",
                    out_name=f"{stamp}.wav",
                )
                if saved_sbv2_wav is not None:
                    p_json["saved_merged_wav"] = str(saved_sbv2_wav)
                    self.log.emit(f"[save] sbv2_wav: {saved_sbv2_wav}")

            _save_text(
                self._cfg.output_dir / "results" / f"{stamp}.json",
                json.dumps(p_json, ensure_ascii=False, indent=2) + "\n",
            )

            female_hold = _wav_duration_sec(p_json.get("merged_wav", ""))
            response_original = str(p_json.get("response_original", p_json.get("response", ""))).strip()
            response_send = str(p_json.get("response", response_original)).strip()
            response_display = str(p_json.get("response_display", response_original)).strip()
            if response_original and response_send == response_original:
                self.log.emit("[tts-conv] send unchanged (no hit or empty replacement)")
            if response_original and response_display == response_original:
                self.log.emit("[tts-conv] display unchanged (display_apply off or no hit)")
            if p_json.get("ok"):
                if response_display:
                    self._send_subtitle(response_display, wav_name, "StackFemale", hold_seconds=female_hold)
                self.log.emit(f"[done] {label}")
            else:
                self.log.emit(f"[error] pipeline: {p_json.get('error', '')}")
                response_original = ""
                response_display = ""
            # 動画切り替え信号は VoiceFaceEventBridge 側へ移管するため、Human_2_kks 側からは送信しない
            matched_indices = self._find_video_indices_from_response(response_original)
            if matched_indices:
                self.log.emit("[video] Human_2_kks からの動画切り替え送信は無効化中")
            # 生テキストをC#へ送信 → C#側でcoord/clothes検出・遅延実行
            if response_display:
                delay = female_hold if female_hold else 0.0
                self._schedule_response_text(response_display, self._cfg.main_index, delay)
            # TTS出力フォルダを削除
            if run_dir is not None and run_dir.exists():
                shutil.rmtree(run_dir, ignore_errors=True)
        except Exception as exc:
            msg = str(exc)
            lower = msg.lower()
            if ("10054" in msg) or ("10061" in msg) or ("connection reset" in lower) or ("connection refused" in lower):
                self._emit_sbv2_diagnostics("pipeline_http_error")
            self.log.emit(f"[error] pipeline {label}: {exc}")


# ---------------------------------------------------------------------------
# ホイール誤爆防止
# ---------------------------------------------------------------------------

